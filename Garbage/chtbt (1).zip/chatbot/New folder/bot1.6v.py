import nltk
import re
from nltk.tokenize import word_tokenize,sent_tokenize
from nltk.corpus import stopwords
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from itertools import permutations
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import make_pipeline
from nltk.stem import WordNetLemmatizer
from itertools import permutations
import math
from sklearn.metrics import accuracy_score
import csv
from difflib import SequenceMatcher
lemmatizer = WordNetLemmatizer() 
stop_words = set(stopwords.words("english"))






def query(statement):
    parse_st = sent_tokenize(statement)
    parse_words = []
    key_words_stop = []
    for i in parse_st:
        j = word_tokenize(i)
        parse_words.append(j)
    for i in parse_words:
        for j in i:
            if j not in stop_words:
                key_words_stop.append(j)
    return key_words_stop







def tagger(statement):
    tokenized = sent_tokenize(statement)
    try:
        for i in tokenized:
            words = nltk.word_tokenize(i)
            tagged = nltk.pos_tag(words)
            ##print(tagged)
            array = np.array(tagged)
            key_words = []
            ##print(array)
            for row in array:
                for i in range(len(row)):
                    if (row[i] == 'JJ' or row[i]=='JJR' or row[i]=='JJS' or row[i]=='VBG' or row[i]=='MD' or row[i]=='IN' or row[i]=='RP'
                        or row[i]=='NN' or row[i]=='NNP'
                        or row[i]=='VB' or row[i]=='VBN' or row[i]=='NNS' or row[i]=='PRP$' or row[i]=='PRP'):
                        row[1]='NN'
                
            ##print(array)
            for row in array:
                ##print(row)
                ##print(len(row))
                for i in range(len(row)):
                    ##print(row[i])
                    if (row[i]=='NN'):
                        key_words.append(row[0])

            #print(key_words)
                    

    except Exception as e:
        print(str(e))
    return key_words











def statement_type(statement):
    df_train =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/simple converstion.csv') ##entering the test date base(csv)
    vectorizer = CountVectorizer()
    counts = vectorizer.fit_transform(df_train['question'].values)
    classifier = MultinomialNB()
    target = df_train['type'].values
    classifier.fit(counts,target)
    example = sent_tokenize(statement)
    example_counts = vectorizer.transform(example)
    predictions = classifier.predict(example_counts)
    return predictions


def database_cleaning():
        df =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv')
        words = []
        lines = np.array(df['A'])
        for i in lines:
            word = i.split()
            tagged = nltk.pos_tag(word)
            
            words.append(tagged)
        ## print(words)
        word_array = np.array(words)

        word_refesh = []
        for j in range(len(words)):
            row_list = []
            for row in words[j]:
                my_list = list(row)
                for i in range(len(my_list)):                    
                    if (my_list[i] == 'JJ' or my_list[i]=='JJR' or my_list[i]=='PRP' or my_list[i]=='IN' or my_list[i]=='RP' or
                        my_list[i]=='JJS' or my_list[i]=='VBG' or my_list[i]=='NN' or my_list[i]=='NNP' or
                        my_list[i]=='VB' or my_list[i]=='VBN' or my_list[i]=='PRP$' or my_list[i]=='NNS' or my_list[i]=='MD'):
                        my_list[1]='NN'
                row_list.append(my_list)
            word_refesh.append(row_list)
                
        #print(word_refesh)
        key = []      
        for j in range(len(word_refesh)):
            mylist = []
            for row in word_refesh[j]:
                for i in range(len(row)):
                    if (row[i]=='NN' ):
                        mylist.append(row[0])    
            key.append((mylist))
        ##print(mylist)
        #print(key)
        return key





def response_struct(): 


    df =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv')
    df_combination = pd.read_csv("C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv")
       
       
    myarray = np.array(df_combination['col'])
    vectorizer = CountVectorizer()
    counts = vectorizer.fit_transform(df['A'].values)
    classifier = MultinomialNB()
    target = df['B'].values
    classifier.fit(counts,target)
    example_counts = vectorizer.transform(myarray)
    predictions_ans = classifier.predict(example_counts)
    return predictions_ans
                    



def final(predictions_ans,key_words,statement):
    df_combination = pd.read_csv("C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv")
    df =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv')
    
    df_combination['ans'] = predictions_ans
    ##print(df_combination['ans'])
    df_combination.to_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv', sep=',',index = False)

    count = []
    print(key_words)
    join_keywords = (' ').join(key_words)
    join = list(join_keywords)
    print(join_keywords)
    myarray = np.array(df_combination['col'])
    ##print(myarray)
    for i in myarray:
        j = i.lower()
        count.append(int((SequenceMatcher(None,join,j).ratio())*10))

    print(count)
    
    if 8 in count or 9 in count or 10 in count or 7 in count or 6 in count:    
         vectorizer = CountVectorizer()
         counts = vectorizer.fit_transform(df_combination['col'].values)
         classifier = MultinomialNB()
         target = df_combination['ans'].values
         classifier.fit(counts,target)
         
         example = sent_tokenize('Aman')
         print(example)
         example_counts = vectorizer.transform(example)
         predict = classifier.predict(example_counts)
         return print(predict)
    else:
         print('not found')
         self_input = input("please feed me the answer-: \n")
         df2  = pd.DataFrame([[statement,self_input]], columns=list('AB'))
         print(df2)
         df = df.append(df2)
         del df['Unnamed: 0']
         ##print(df)
         df.to_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv', sep=',')

    

def comb_for_four(key):
    list_all_comb_four = []
    list4 = []
    for i in key:
        if len(i)==4:
          list4.append(i)
    #print(list4)
    for i in list4:
        for x in permutations(i):
            v = list(x)
            list_all_comb_four.append(" ".join(v))
    return list_all_comb_four

def comb_for_three(key):
    list_all_comb_three = []
    list3 = []
    for i in key:
        if len(i)==3:
          list3.append(i)
    #print(list3)
    for i in list3:
        for x in permutations(i):
            v = list(x)
            list_all_comb_three.append(" ".join(v))
    return list_all_comb_three

def comb_for_two(key):
    list_all_comb_two = []
    list2 = []
    for i in key:
        if len(i)== 2:
          list2.append(i)
    #print(list2)
    for i in list2:
        for x in permutations(i):
            v = list(x)
            list_all_comb_two.append(" ".join(v))
    return list_all_comb_two

def comb_for_one(key):
    list_all_comb_one = []
    list1 = []
    ##print(key)
    for i in key:
        if len(i)==1:
          list1.append(i)
    for i in list1:
        for j in i:
            list_all_comb_one.append(j)

    return list_all_comb_one
    #print(list)

def comb_for_five(key):
    list_all_comb_five = []
    list5 = []
    for i in key:
        if len(i)==5:
          list5.append(i)
    #print(list
    for i in list5:
        for x in permutations(i):
            v = list(x)
            list_all_comb_five.append(" ".join(v))
    return list_all_comb_five


def all_comb_csv(list_all_comb_four,list_all_comb_three,list_all_comb_two,list_all_comb_five,list_all_comb_one):
    f = open("C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv", "w")
    f.truncate()
    columnTitleRow = [["col","ans"]]
    writer = csv.writer(f)
    writer.writerows(columnTitleRow)
    f.close()
    
    df_comb =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv')
    ##print(df_comb)
    df_comb4 = pd.DataFrame({'col':list_all_comb_four})

    df_comb3  = pd.DataFrame({'col':list_all_comb_three})
   
    df_comb2  = pd.DataFrame({'col':list_all_comb_two})
    
    df_comb5  = pd.DataFrame({'col':list_all_comb_five})

    df_comb1  = pd.DataFrame({'col':list_all_comb_one})
    
    df_comb   = df_comb.append(df_comb4)

    df_comb   = df_comb.append(df_comb1)
    
    df_comb   = df_comb.append(df_comb3)
    
    df_comb   = df_comb.append(df_comb2)
    
    df_comb   = df_comb.append(df_comb5)

    df_comb.to_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv', sep=',',index = False)
    Comb_Array = np.array(df_comb['col'])
    ##print(Comb_Array.shape)
    Comb_Array = Comb_Array.reshape((len(Comb_Array),1))
    ##print(Comb_Array.shape)
    ##Comb_list = list(Comb_Array)
    return Comb_Array











  
greeting = input('hi! I am intertek buddy!  welcome, say hi to start \n')
while(greeting !='exit'):
    statement = input('how can i help you \n')
    if (statement == 'exit'):
        break
    if (statement == "" or statement == " "):
        print("blanks are not allowed")
        continue
    else:
        key = database_cleaning()
        four = comb_for_four(key)
        one = comb_for_one(key)
        ##print(one)
        three = comb_for_three(key)
        two = comb_for_two(key)
        one = comb_for_one(key)
        ##print(two)
        five = comb_for_five(key)
        Comb_Array = all_comb_csv(four,three,two,five,one)
        key_words_stop = query(statement)
        key_words = tagger(statement)
        pred = statement_type(statement)
        ##print(pred)
        predictions_ans = response_struct()
        
        final(predictions_ans,key_words,statement)
            
