import nltk
import re
from nltk.tokenize import word_tokenize,sent_tokenize
from nltk.corpus import stopwords
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from itertools import permutations
from sklearn.naive_bayes import MultinomialNB
from nltk.stem import WordNetLemmatizer
from itertools import permutations
import math
import csv
lemmatizer = WordNetLemmatizer() 
stop_words = set(stopwords.words("english"))
##print(stop_words)
greetings = ['hi','hello','whatsup','yo','dude','yellowwww']





def query(statement):
    parse_st = sent_tokenize(statement)
    parse_words = []
    key_words_stop = []
    for i in parse_st:
        j = word_tokenize(i)
        parse_words.append(j)
    for i in parse_words:
        for j in i:
            if j not in stop_words:
                key_words_stop.append(j)
    return key_words_stop







def tagger(statement):
    tokenized = sent_tokenize(statement)
    try:
        for i in tokenized:
            words = nltk.word_tokenize(i)
            tagged = nltk.pos_tag(words)
            ##print(tagged)
            array = np.array(tagged)
            key_words = []
            ##print(array)
            for row in array:
                for i in range(len(row)):
                    if (row[i] == 'JJ' or row[i]=='JJR' or row[i]=='JJS' or row[i]=='VBG' or row[i]=='VB' or row[i]=='VBN'):
                        row[1]='NN'
                
            ##print(array)
            for row in array:
                ##print(row)
                ##print(len(row))
                for i in range(len(row)):
                    ##print(row[i])
                    if (row[i] == 'WP' or row[i]=='NN' or row[i]=='WDT' or row[i]=='WRB' or row[i]=='WP$'):
                        key_words.append(row[0])

           ## print(key_words)
                    

    except Exception as e:
        print(str(e))
    return key_words








def jawab(key_words):
    response = response_struct()
    for i in key_words:
        for j in greetings:
            if (i == j and len(key_words)==1) :
                print('hi '+ response)
            else:
                print(response)




def statement_type(statement):
    df_train =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/simple converstion.csv') ##entering the test date base(csv)
    vectorizer = CountVectorizer()
    counts = vectorizer.fit_transform(df_train['question'].values)
    classifier = MultinomialNB()
    target = df_train['type'].values
    classifier.fit(counts,target)
    example = sent_tokenize(statement)
    example_counts = vectorizer.transform(example)
    predictions = classifier.predict(example_counts)
    return predictions


def database_cleaning():
        df =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv')
        words = []
        lines = np.array(df['A'])
        for i in lines:
            word = i.split()
            tagged = nltk.pos_tag(word)
            
            words.append(tagged)
        ## print(words)
        word_array = np.array(words)

        word_refesh = []
        for j in range(len(words)):
            row_list = []
            for row in words[j]:
                my_list = list(row)
                for i in range(len(my_list)):                    
                    if (my_list[i] == 'JJ' or my_list[i]=='JJR' or
                        my_list[i]=='JJS' or my_list[i]=='VBG' or
                        my_list[i]=='VB' or my_list[i]=='VBN' or my_list[i]=='PRP$'):
                        my_list[1]='NN'
                row_list.append(my_list)
            word_refesh.append(row_list)
                
        #print(word_refesh)
        key = []      
        for j in range(len(word_refesh)):
            mylist = []
            for row in word_refesh[j]:
                for i in range(len(row)):
                    if (row[i] == 'WP' or row[i]=='NN' or row[i]=='WDT' or row[i]=='WRB' or row[i]=='WP$'):
                        mylist.append(row[0])    
            key.append((mylist))
        ##print(mylist)
        #print(key)
        return key





def response_struct(prediction,key_words,key_words_stop,key,Comb_list):## prediction - statement struct; key_words - tagger ; key_words_stop, 
    if (prediction == 'Q'):
    ##print(st_parse)
        df =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv')
        ##33print(words)
        count = []
        
        result = 0
        join_keywords = (' ').join(key_words)
        ##print(join_keywords)
        for j in Comb_Array:
            if j==join_keywords:
                count.append(1)
            else:
                count.append(0)

        ##print(count)
        for i in range(len(count)):
            result = count[i] + result
        ##print(result)
        if result ==0 :
            print('not found')
            self_input = input("please feed me the answer-: \n")
            df2  = pd.DataFrame([[statement,self_input]], columns=list('AB'))
            ##print(df)
            df = df.append(df2)
            del df['Unnamed: 0']
            ##print(df)
            df.to_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv', sep=',')
    
        else:
            vectorizer = CountVectorizer()
            counts = vectorizer.fit_transform(df['A'].values)
            classifier = MultinomialNB()
            target = df['B'].values
            classifier.fit(counts,target)
            example = sent_tokenize(join_keywords)
            example_counts = vectorizer.transform(example)
            predictions = classifier.predict(example_counts)
            return print(predictions)








def comb_for_four(key):
    list_all_comb_four = []
    list4 = []
    for i in key:
        if len(i)==4:
          list4.append(i)
    #print(list4)
    for i in list4:
        for x in permutations(i):
            v = list(x)
            list_all_comb_four.append(" ".join(v))
    return list_all_comb_four

def comb_for_three(key):
    list_all_comb_three = []
    list3 = []
    for i in key:
        if len(i)==3:
          list3.append(i)
    #print(list3)
    for i in list3:
        for x in permutations(i):
            v = list(x)
            list_all_comb_three.append(" ".join(v))
    return list_all_comb_three

def comb_for_two(key):
    list_all_comb_two = []
    list2 = []
    for i in key:
        if len(i)== 2:
          list2.append(i)
    #print(list2)
    for i in list2:
        for x in permutations(i):
            v = list(x)
            list_all_comb_two.append(" ".join(v))
    return list_all_comb_two

def comb_for_five(key):
    list_all_comb_five = []
    list5 = []
    for i in key:
        if len(i)==5:
          list5.append(i)
    #print(list5)
    for i in list5:
        for x in permutations(i):
            v = list(x)
            list_all_comb_five.append(" ".join(v))
    return list_all_comb_five


def all_comb_csv(list_all_comb_four,list_all_comb_three,list_all_comb_two,list_all_comb_five):
    f = open("C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv", "w")
    f.truncate()
    columnTitleRow = [["col"]]
    writer = csv.writer(f)
    writer.writerows(columnTitleRow)
    f.close()
    
    df_comb =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv')
    print(df_comb)

    df_comb4 = pd.DataFrame({'col':list_all_comb_four})

    df_comb3  = pd.DataFrame({'col':list_all_comb_three})
   
    df_comb2  = pd.DataFrame({'col':list_all_comb_two})
    
    df_comb5  = pd.DataFrame({'col':list_all_comb_five})
    
    df_comb   = df_comb.append(df_comb4)
    
    df_comb   = df_comb.append(df_comb3)
    
    df_comb   = df_comb.append(df_comb2)
    
    df_comb   = df_comb.append(df_comb5)

    df_comb.to_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/all_combinations.csv', sep=',')
    Comb_Array = np.array(df_comb['col'])
    Comb_list = list(Comb_Array)
    return Comb_list






def ultimate_key(Comb_list):
    #print(Comb_list)
    df_ques_ans =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ques_ans.csv')
    df_ultimate_key =  pd.read_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ultimate_key.csv')
    df_ultimate_key['question'] = Comb_list
    key_two = []
    key_two_stop = []
    for i in Comb_list:
        j = i.split()
        key_two.append(j)
    for i in key_two:
        for j in i:
            if j not in stop_words:
                key_two_stop.append(j)
    print(key_two_stop)         
    df_ultimate_key['key'] = key_two_stop
    df_ultimate_key.to_csv('C:/Users/rakshit.makan/Desktop/Python/chat bot/New WinRAR ZIP archive/Files/ultimate_key.csv', sep=',')
    return print(df_ultimate_key)





  
greeting = input('hi! I am intertek buddy!  welcome, say hi to start \n')
while(greeting !='exit'):
    statement = input('how can i help you \n')
    if (statement == 'exit'):
        break
    else:
        key = database_cleaning()
        four = comb_for_four(key)
        #print(four)
        three = comb_for_three(key)
        two = comb_for_two(key)
        #print(two)
        five = comb_for_five(key)
        Comb_list = all_comb_csv(four,three,two,five)
        ultimate_key(Comb_list)
        key_words_stop = query(statement)
        key_words = tagger(statement)
        print()
        pred = statement_type(statement)
        ##print(pred)
        response_struct(pred,key_words,key_words_stop,key,Comb_list)
